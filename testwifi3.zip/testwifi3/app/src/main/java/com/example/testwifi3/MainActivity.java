package com.example.testwifi3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.net.URISyntaxException;
public class MainActivity extends AppCompatActivity {
    private static final String SERVER_IP = "192.168.1.10"; // Replace with the IP address of your Raspberry Pi Pico board
    private static final int SERVER_PORT = 80; // Replace with the port number used by the Python code

    private Button btnOn, btnOff;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOn = (Button) findViewById(R.id.btn_on);
        btnOff = (Button) findViewById(R.id.btn_off);

        btnOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LedControlTask().execute("1");
            }
        });

        btnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new LedControlTask().execute("0");
            }
        });
    }
        private class LedControlTask extends AsyncTask<String, Void, Void> {

            @Override
            protected Void doInBackground(String... params) {
                try {
                    Socket socket = new Socket(SERVER_IP, SERVER_PORT);
                    PrintWriter out = new PrintWriter(new OutputStreamWriter(socket.getOutputStream()), true);
                    BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

                    String message = params[0];
                    out.println(message);
                    String response = in.readLine();
                    socket.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }
        }

}